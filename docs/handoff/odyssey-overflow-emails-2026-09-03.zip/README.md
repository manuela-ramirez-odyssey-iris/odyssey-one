# Overflow Email Set — Handoff

Eight emails produced by one overflow (spot-bid) quote lifecycle, exported from
the seeded sample in `src/routes/spot-emails/fixture.js` for test-send and
implementation reference.

## The eight emails

| ID | Recipient | Sent | Trigger condition |
|----|-----------|------|--------------------|
| CE-1 | Carrier | On Send RFQ | Request for Quote to CCNI for Quote No: 14903, for ACME CHEMICAL COMPANY |
| CE-2 | Carrier | On award | Quote Request 14903 Awarded |
| IE-1 | Planning group | On close | Attention - Quote Request 14903 closed with no carrier bids submitted. |
| IE-2 | Planning group | On close | Attention - Quote Request 14903 closed and the lowest cost carrier is out of tolerance. |
| IE-3 | Planning group | On close | Attention - Quote Request 14903 closed and Manual Review = Yes.  Please review quote responses immediately. |
| IE-4 | Planning group | On close | Attention - Quote Request 14903 Cancelled, Consolidation Impacted by Order Change |
| IE-5 | Planning group | On close | Attention - Quote Request 14903 closed and no costed LCE option exists to determine quote tolerance. |
| IE-6 | Planning group | On close | Attention - Quote Request 14903 closed and no distance was found to calculate an estimated costed LCE option. |

**Carrier / planner split**: `CE-1` (Request for Quote) goes to every included
carrier when the planner sends the RFQ; one copy per carrier, each with its own
bid link. `CE-2` (Awarded) goes to the winning carrier only. The six `IE-*`
alerts (`IE-1`…`IE-6`) all go to the planning group when the quote closes —
they are the exception report a planner reads, not a lane summary. Precedence
between them (cancellation → no bids → cannot-evaluate-tolerance → tolerance
verdict) is in `alertKind.js`.

## Outlook safety

Every `.html` file here is Outlook-safe: table layout, inline styles only, no
CSS variables/flexbox/grid/`border-radius`/web fonts, fixed 600px width. Do not
"improve" the markup with modern CSS — Outlook's Word rendering engine will
silently drop it.

## Send as multipart

Each email has a plain-text twin (`.txt`). Send both together as a
`multipart/alternative` message (text first, then HTML) — never HTML-only.

## Sender / recipients

- **From**: the planning group's `FROMEMAIL` mailbox (a TMS system profile per
  planning group — SPB-77). This export's sample uses a seeded placeholder
  (`planning-charlotte@odysseylogistics.com`); production reads the real
  profile.
- **Carrier recipients** (`CE-1`, `CE-2`): come from the TMS carrier
  communications config, not this app.
- **Planner recipients** (`IE-*`): the planning group's `FROMEMAIL` mailbox
  (same one used as sender), so alerts land back with the group that owns the
  quote.

## Dynamic fields

The `{{...}}`-style values you'll see in these renders are seeded sample data
(one demo quote — see `fixture.js`), not live production values. Fields that
are dynamic per quote:

- Quote ID, Reference #, Order #
- Shipper name, Ship From / Ship To addresses
- Equipment, weight, hazmat flag, distance
- Pickup / delivery dates, stop-offs (multi-stop TL)
- Offer expiry timestamp
- Carrier name, SCAC, email (per `CE-1`/`CE-2` recipient)
- Lowest-bid block: carrier, amount, ship date, delivery date (`IE-2`/`IE-3`/`IE-5`/`IE-6`, and `CE-2`'s award rate)
- The carrier's token bid link (`CE-1` only — `/spot-bid/:token`)

## Logo

`assets/odyssey-one-logo.png` is included for self-hosting. The exported HTML
already points `<img src>` at the absolute production URL
(`https://odyssey-one-stage.vercel.app/email/odyssey-one-logo.png`) so the
files render correctly opened from disk or test-sent from anywhere.

## Source

`source/` holds the six files that produce these emails:
`emailTheme.js`, `emailLayout.js`, `templates.js`, `alertKind.js`,
`emailContext.js`, `emailsForQuote.js` — all under
`apps/odyssey-one/src/spotboard/email/` in the repo.

## Canon

`vault/10-domains/spotboard/data/quote-model.md` §7.1 (Doug's 2023 sample
send — the verbatim legacy text skeletons these templates mirror), and
decisions SPB-05 (carrier emails carry no Reference#/Order#), SPB-63,
SPB-77 (FROMEMAIL is a TMS per-planning-group profile), SPB-78 (planner
alert precedence / PRD Feature 11).
